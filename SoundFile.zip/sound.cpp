#include "sound.h"
#include <iostream>
#include <cstdlib>
#include <Windows.h>
#include <MMSystem.h>

sound::sound(const char* sound_filename) {
	filename = sound_filename;
}

void sound::play() {
	PlaySound(TEXT(filename), NULL, SND_FILENAME | SND_ASYNC | SND_LOOP);
}
void sound::stop() {
	PlaySound(NULL, 0, 0);
}

void sound::playOnce() {
	
}

sound::~sound() {
	stop();
}
