#include <iostream>
#include "App.h"

App* singleton;
AnimatedRect* movement;

void timer(int id){
    // This will get called every 16 milliseconds after
    // you call it once
    
    // If you want to manipulate the app in here
    // do it through the singleton pointer    


    glutTimerFunc(16, timer, id);
}

App::App(int argc, char** argv, int width, int height, const char* title): GlutApp(argc, argv, width, height, title){
	pacman = new AnimatedRect("pacman.png", 4, 5, 20, true, true, 0.0,  0.0, 0.25, 0.25);

    
    singleton = this;    
    timer(1);
}

void App::draw() {
	//explode->draw(0.0);
	pacman->draw(0.5);
}

void App::keyDown(unsigned char key, float x, float y){
    if (key == 27){
        exit(0);
    }
    if (key == 'w'){
		pacman->up();
    }
	if (key == 'a') {
		pacman->left();
	}
	if (key == 'd') {
		pacman->right();
	}
	if (key == 's') {
		pacman->down();
	}
}

App::~App(){
    delete pacman;
    std::cout << "Exiting..." << std::endl;
}
