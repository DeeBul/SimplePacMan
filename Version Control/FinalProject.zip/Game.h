#ifndef Game_hpp
#define Game_hpp

#include "AppComponent.h"
#include "AnimatedRect.h"
#include "pacChar.h"
#include "Timer.h"

class Game: public AppComponent, private Timer{
	float size;
	float speed;

	pacChar* pacman;
	AnimatedRect* blinky;														// Blinky = Red Ghost
	AnimatedRect* pinky;														// Pinky = Pink Ghost (Duh)
	AnimatedRect* inky;															// Inky = Cyan Ghost
	AnimatedRect* clyde;

	bool moving;
	bool moveUp;
	bool moveDown;
	bool moveLeft;
	bool moveRight;
	bool soundPlaying;
	bool collision;
public:
    AnimatedRect* explosion;
    Game();
    
    void draw() const ;
    void handleKeyDown(unsigned char, float, float);
	//void handleKeyUp(unsigned char, float, float);
    void action();

    ~Game();

};

#endif 
