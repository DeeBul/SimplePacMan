#define _USE_MATH_DEFINES
#include <cmath>
#include <iostream>
#include <cstdlib>
#include <Windows.h>
#include <MMSystem.h>
#include "Game.h"



Game::Game(){

	// Some cross-platform compatimility stuff

	const char* shroomFileName;
	const char* fireballFileName;

	// In Windows (Visual Studio only) the image files are found in the enclosing folder in relation to the project
	// In other environments the image files are in the same folder as the project

	size = 0.2;
	speed = 0.001;

	pacman = new pacChar("pacman.png", 4, 5, 20, true, true, true, 0.0, 0.0, size, size);
	blinky = new AnimatedRect("Blinky-Down.png", 1, 2, 100, true, true, -0.8, 0.6, size, size);
	pinky = new AnimatedRect("Pinky-Down.png", 1, 2, 100, true, true, -0.4, 0.6, size, size);
	inky = new AnimatedRect("Inky-Down.png", 1, 2, 100, true, true, 0.2, 0.6, size, size);
	clyde = new AnimatedRect("Clyde-Down.png", 1, 2, 100, true, true, 0.6, 0.6, size, size);

	moving = false;
	moveUp = false;
	moveDown = false;
	moveLeft = false;
	moveRight = false;
	soundPlaying = false;
	collision = false;
    
    setRate(1);
    start();
}

void Game::action(){
	float mx = pacman->getX();
    float my = pacman->getY();
    
	if (moveUp) {
		pacman->setY(my + speed);
		moveLeft = false;
		moveRight = false;
		moveDown = false;
		std::cout << "Moving up" << std::endl;
		if (!soundPlaying) {
			soundPlaying = true;
			PlaySound(TEXT("pacman_chomp.wav"), NULL, SND_FILENAME | SND_ASYNC | SND_LOOP);
		}
	}
	if (moveDown) {
		pacman->setY(my - speed);
		moveUp = false;
		moveLeft = false;
		moveRight = false;
		std::cout << "Moving down" << std::endl;
		if (!soundPlaying) {
			soundPlaying = true;
			PlaySound(TEXT("pacman_chomp.wav"), NULL, SND_FILENAME | SND_ASYNC | SND_LOOP);
		}
	}
	if (moveLeft) {
		pacman->setX(mx - speed);
		moveUp = false;
		moveRight = false;
		moveDown = false;
		std::cout << "Moving left" << std::endl;
		if (!soundPlaying) {
			soundPlaying = true;
			PlaySound(TEXT("pacman_chomp.wav"), NULL, SND_FILENAME | SND_ASYNC | SND_LOOP);
		}
	}
	if (moveRight) {
		pacman->setX(mx + speed);
		moveUp = false;
		moveLeft = false;
		moveDown = false;
		std::cout << "Moving right" << std::endl;
		if (!soundPlaying) {
			soundPlaying = true;
			PlaySound(TEXT("pacman_chomp.wav"), NULL, SND_FILENAME | SND_ASYNC | SND_LOOP);
		}
	}    
}

void Game::draw() const {
	pacman->draw(0.5);
	blinky->draw(0.6);
	pinky->draw(0.7);
	inky->draw(0.8);
	clyde->draw(0.9);
}

void Game::handleKeyDown(unsigned char key, float x, float y){
    if (key == 'p'){
        stop();
    }
    else if (key == 'r'){
        start();
    }
	if (key == 'w') {
		pacman->up();
		moving = true;
		moveUp = true;		
		soundPlaying = true;
	}
	if (key == 'a') {
		pacman->left();
		moving = true;
		moveLeft = true;
		soundPlaying = true;
	}
	if (key == 'd') {
		pacman->right();
		moving = true;
		moveRight = true;
		soundPlaying = true;
	}
	if (key == 's') {
		pacman->down();
		moving = true;
		moveDown = true;
		soundPlaying = true;
	}
	if (key == ']') {
		if (speed <= 0.01 - 0.0001) {
			speed += 0.0001;
		}		
	}
	if (key == '[') {
		if (speed >= 0.0001) {
			speed -= 0.0001;
		}
	}
	if (key == ' ') {
		moving = false;
		soundPlaying = false;
		PlaySound(NULL, 0, 0);
	}
}

Game::~Game(){
    stop();
	delete pacman;
	delete pinky;
	delete blinky;
	delete inky;
	delete clyde;
}
